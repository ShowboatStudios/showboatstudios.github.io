Planet Pass (App Store: Planet Pass Geo) by Showboat Studios
Real iPhone Duo device captures. 'inner' = the big folding screen, 'cover' = the outside screen.
Free to use for coverage of the app. Contact: showboatcontact@gmail.com
